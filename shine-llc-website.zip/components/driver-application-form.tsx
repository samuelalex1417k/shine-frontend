"use client"

import { useState } from "react"
import { cn } from "@/lib/utils"
import { CheckCircle2, Upload } from "lucide-react"

const TOTAL_STEPS = 4

const stepLabels = [
  "Personal Info",
  "License Details",
  "Vehicle Info",
  "Consent & Submit",
]

interface FormData {
  fullName: string
  phone: string
  email: string
  address: string
  licenseNumber: string
  expiryDate: string
  yearsExperience: string
  vehicleMake: string
  vehicleModel: string
  vehicleYear: string
  licenseFile: File | null
  insuranceFile: File | null
  backgroundConsent: boolean
}

const initialFormData: FormData = {
  fullName: "",
  phone: "",
  email: "",
  address: "",
  licenseNumber: "",
  expiryDate: "",
  yearsExperience: "",
  vehicleMake: "",
  vehicleModel: "",
  vehicleYear: "",
  licenseFile: null,
  insuranceFile: null,
  backgroundConsent: false,
}

export function DriverApplicationForm() {
  const [step, setStep] = useState(1)
  const [formData, setFormData] = useState<FormData>(initialFormData)
  const [submitted, setSubmitted] = useState(false)

  function handleChange(
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) {
    const { name, value, type } = e.target
    if (type === "checkbox") {
      setFormData((prev) => ({
        ...prev,
        [name]: (e.target as HTMLInputElement).checked,
      }))
    } else if (type === "file") {
      const files = (e.target as HTMLInputElement).files
      setFormData((prev) => ({
        ...prev,
        [name]: files?.[0] || null,
      }))
    } else {
      setFormData((prev) => ({ ...prev, [name]: value }))
    }
  }

  function nextStep() {
    if (step < TOTAL_STEPS) setStep((s) => s + 1)
  }

  function prevStep() {
    if (step > 1) setStep((s) => s - 1)
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setSubmitted(true)
  }

  if (submitted) {
    return (
      <div className="rounded-lg border border-accent/30 bg-accent/5 p-8 text-center sm:p-12">
        <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-accent/10">
          <CheckCircle2 className="h-7 w-7 text-accent" />
        </div>
        <h3 className="mt-5 text-xl font-bold text-foreground">
          Application Received
        </h3>
        <p className="mt-3 text-muted-foreground max-w-md mx-auto leading-relaxed">
          Your application has been received. Our team will review and contact
          you within 3-5 business days.
        </p>
      </div>
    )
  }

  return (
    <div>
      {/* Step Indicator */}
      <div className="mb-8">
        <div className="flex items-center justify-between">
          {stepLabels.map((label, index) => {
            const stepNum = index + 1
            const isActive = step === stepNum
            const isComplete = step > stepNum

            return (
              <div key={label} className="flex flex-1 flex-col items-center">
                <div className="flex items-center w-full">
                  {index > 0 && (
                    <div
                      className={cn(
                        "h-0.5 flex-1",
                        isComplete || isActive
                          ? "bg-primary"
                          : "bg-border"
                      )}
                    />
                  )}
                  <div
                    className={cn(
                      "flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-xs font-semibold transition-colors",
                      isComplete
                        ? "bg-primary text-primary-foreground"
                        : isActive
                        ? "bg-primary text-primary-foreground"
                        : "bg-secondary text-muted-foreground border border-border"
                    )}
                  >
                    {isComplete ? (
                      <CheckCircle2 className="h-4 w-4" />
                    ) : (
                      stepNum
                    )}
                  </div>
                  {index < stepLabels.length - 1 && (
                    <div
                      className={cn(
                        "h-0.5 flex-1",
                        isComplete ? "bg-primary" : "bg-border"
                      )}
                    />
                  )}
                </div>
                <span
                  className={cn(
                    "mt-2 text-xs font-medium hidden sm:block",
                    isActive
                      ? "text-foreground"
                      : isComplete
                      ? "text-primary"
                      : "text-muted-foreground"
                  )}
                >
                  {label}
                </span>
              </div>
            )
          })}
        </div>
      </div>

      <form onSubmit={handleSubmit}>
        {/* Step 1: Personal Information */}
        {step === 1 && (
          <div className="flex flex-col gap-5">
            <h3 className="text-lg font-semibold text-foreground">
              Personal Information
            </h3>
            <div>
              <label
                htmlFor="fullName"
                className="block text-sm font-medium text-foreground"
              >
                Full Name *
              </label>
              <input
                id="fullName"
                name="fullName"
                type="text"
                required
                value={formData.fullName}
                onChange={handleChange}
                className="mt-1.5 w-full rounded-md border border-input bg-background px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:border-ring focus:outline-none focus:ring-1 focus:ring-ring"
                placeholder="John Doe"
              />
            </div>
            <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
              <div>
                <label
                  htmlFor="phone"
                  className="block text-sm font-medium text-foreground"
                >
                  Phone *
                </label>
                <input
                  id="phone"
                  name="phone"
                  type="tel"
                  required
                  value={formData.phone}
                  onChange={handleChange}
                  className="mt-1.5 w-full rounded-md border border-input bg-background px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:border-ring focus:outline-none focus:ring-1 focus:ring-ring"
                  placeholder="(123) 456-7890"
                />
              </div>
              <div>
                <label
                  htmlFor="email"
                  className="block text-sm font-medium text-foreground"
                >
                  Email *
                </label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  required
                  value={formData.email}
                  onChange={handleChange}
                  className="mt-1.5 w-full rounded-md border border-input bg-background px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:border-ring focus:outline-none focus:ring-1 focus:ring-ring"
                  placeholder="john@example.com"
                />
              </div>
            </div>
            <div>
              <label
                htmlFor="address"
                className="block text-sm font-medium text-foreground"
              >
                Address *
              </label>
              <input
                id="address"
                name="address"
                type="text"
                required
                value={formData.address}
                onChange={handleChange}
                className="mt-1.5 w-full rounded-md border border-input bg-background px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:border-ring focus:outline-none focus:ring-1 focus:ring-ring"
                placeholder="123 Main St, City, State, ZIP"
              />
            </div>
          </div>
        )}

        {/* Step 2: License Details */}
        {step === 2 && (
          <div className="flex flex-col gap-5">
            <h3 className="text-lg font-semibold text-foreground">
              Driver License Details
            </h3>
            <div>
              <label
                htmlFor="licenseNumber"
                className="block text-sm font-medium text-foreground"
              >
                {"Driver's License Number *"}
              </label>
              <input
                id="licenseNumber"
                name="licenseNumber"
                type="text"
                required
                value={formData.licenseNumber}
                onChange={handleChange}
                className="mt-1.5 w-full rounded-md border border-input bg-background px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:border-ring focus:outline-none focus:ring-1 focus:ring-ring"
                placeholder="DL-123456789"
              />
            </div>
            <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
              <div>
                <label
                  htmlFor="expiryDate"
                  className="block text-sm font-medium text-foreground"
                >
                  Expiry Date *
                </label>
                <input
                  id="expiryDate"
                  name="expiryDate"
                  type="date"
                  required
                  value={formData.expiryDate}
                  onChange={handleChange}
                  className="mt-1.5 w-full rounded-md border border-input bg-background px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:border-ring focus:outline-none focus:ring-1 focus:ring-ring"
                />
              </div>
              <div>
                <label
                  htmlFor="yearsExperience"
                  className="block text-sm font-medium text-foreground"
                >
                  Years of Driving Experience *
                </label>
                <select
                  id="yearsExperience"
                  name="yearsExperience"
                  required
                  value={formData.yearsExperience}
                  onChange={handleChange}
                  className="mt-1.5 w-full rounded-md border border-input bg-background px-3 py-2.5 text-sm text-foreground focus:border-ring focus:outline-none focus:ring-1 focus:ring-ring"
                >
                  <option value="">Select experience</option>
                  <option value="0-1">Less than 1 year</option>
                  <option value="1-3">1-3 years</option>
                  <option value="3-5">3-5 years</option>
                  <option value="5-10">5-10 years</option>
                  <option value="10+">10+ years</option>
                </select>
              </div>
            </div>
          </div>
        )}

        {/* Step 3: Vehicle Information */}
        {step === 3 && (
          <div className="flex flex-col gap-5">
            <h3 className="text-lg font-semibold text-foreground">
              Vehicle Information
            </h3>
            <div className="grid grid-cols-1 gap-5 sm:grid-cols-3">
              <div>
                <label
                  htmlFor="vehicleMake"
                  className="block text-sm font-medium text-foreground"
                >
                  Vehicle Make *
                </label>
                <input
                  id="vehicleMake"
                  name="vehicleMake"
                  type="text"
                  required
                  value={formData.vehicleMake}
                  onChange={handleChange}
                  className="mt-1.5 w-full rounded-md border border-input bg-background px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:border-ring focus:outline-none focus:ring-1 focus:ring-ring"
                  placeholder="Toyota"
                />
              </div>
              <div>
                <label
                  htmlFor="vehicleModel"
                  className="block text-sm font-medium text-foreground"
                >
                  Vehicle Model *
                </label>
                <input
                  id="vehicleModel"
                  name="vehicleModel"
                  type="text"
                  required
                  value={formData.vehicleModel}
                  onChange={handleChange}
                  className="mt-1.5 w-full rounded-md border border-input bg-background px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:border-ring focus:outline-none focus:ring-1 focus:ring-ring"
                  placeholder="Sienna"
                />
              </div>
              <div>
                <label
                  htmlFor="vehicleYear"
                  className="block text-sm font-medium text-foreground"
                >
                  Vehicle Year *
                </label>
                <input
                  id="vehicleYear"
                  name="vehicleYear"
                  type="number"
                  required
                  min={2000}
                  max={2030}
                  value={formData.vehicleYear}
                  onChange={handleChange}
                  className="mt-1.5 w-full rounded-md border border-input bg-background px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:border-ring focus:outline-none focus:ring-1 focus:ring-ring"
                  placeholder="2023"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
              <div>
                <label
                  htmlFor="licenseFile"
                  className="block text-sm font-medium text-foreground"
                >
                  {"Upload Driver's License *"}
                </label>
                <label
                  htmlFor="licenseFile"
                  className="mt-1.5 flex cursor-pointer items-center gap-2 rounded-md border border-dashed border-input bg-background px-4 py-6 text-sm text-muted-foreground hover:bg-secondary/30 transition-colors"
                >
                  <Upload className="h-5 w-5 shrink-0" />
                  <span>
                    {formData.licenseFile
                      ? formData.licenseFile.name
                      : "Click to upload license"}
                  </span>
                </label>
                <input
                  id="licenseFile"
                  name="licenseFile"
                  type="file"
                  accept=".pdf,.jpg,.jpeg,.png"
                  onChange={handleChange}
                  className="sr-only"
                />
              </div>
              <div>
                <label
                  htmlFor="insuranceFile"
                  className="block text-sm font-medium text-foreground"
                >
                  Upload Insurance Document *
                </label>
                <label
                  htmlFor="insuranceFile"
                  className="mt-1.5 flex cursor-pointer items-center gap-2 rounded-md border border-dashed border-input bg-background px-4 py-6 text-sm text-muted-foreground hover:bg-secondary/30 transition-colors"
                >
                  <Upload className="h-5 w-5 shrink-0" />
                  <span>
                    {formData.insuranceFile
                      ? formData.insuranceFile.name
                      : "Click to upload insurance"}
                  </span>
                </label>
                <input
                  id="insuranceFile"
                  name="insuranceFile"
                  type="file"
                  accept=".pdf,.jpg,.jpeg,.png"
                  onChange={handleChange}
                  className="sr-only"
                />
              </div>
            </div>
          </div>
        )}

        {/* Step 4: Background Check Consent */}
        {step === 4 && (
          <div className="flex flex-col gap-5">
            <h3 className="text-lg font-semibold text-foreground">
              Background Check Consent
            </h3>
            <div className="rounded-lg border border-border bg-secondary/30 p-6">
              <p className="text-sm leading-relaxed text-muted-foreground">
                By submitting this application, you authorize Shine LLC to
                conduct a comprehensive background check, including but not
                limited to criminal history, driving record, and employment
                verification. This information will be used solely for the
                purpose of evaluating your application for a driver position with
                Shine LLC. All information will be handled in compliance with
                applicable federal and state laws.
              </p>
            </div>
            <label className="flex items-start gap-3 cursor-pointer">
              <input
                type="checkbox"
                name="backgroundConsent"
                checked={formData.backgroundConsent}
                onChange={handleChange}
                required
                className="mt-1 h-4 w-4 rounded border-input text-primary focus:ring-ring"
              />
              <span className="text-sm text-foreground leading-relaxed">
                I consent to a background check and confirm that all information
                provided in this application is true and accurate to the best of
                my knowledge. *
              </span>
            </label>
          </div>
        )}

        {/* Navigation Buttons */}
        <div className="mt-8 flex items-center justify-between">
          {step > 1 ? (
            <button
              type="button"
              onClick={prevStep}
              className="inline-flex items-center justify-center rounded-md border border-border bg-background px-5 py-2.5 text-sm font-medium text-foreground transition-colors hover:bg-secondary"
            >
              Previous
            </button>
          ) : (
            <div />
          )}

          {step < TOTAL_STEPS ? (
            <button
              type="button"
              onClick={nextStep}
              className="inline-flex items-center justify-center rounded-md bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
            >
              Continue
            </button>
          ) : (
            <button
              type="submit"
              disabled={!formData.backgroundConsent}
              className="inline-flex items-center justify-center rounded-md bg-accent px-8 py-2.5 text-sm font-semibold text-accent-foreground transition-colors hover:bg-accent/90 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Submit Application
            </button>
          )}
        </div>
      </form>
    </div>
  )
}
